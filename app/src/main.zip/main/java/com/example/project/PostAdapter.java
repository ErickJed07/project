// PostAdapter.java
package com.example.project;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {

    private List<Post> postList;
    private OnItemClickListener listener;

    // Define the interface
    public interface OnItemClickListener {
        void onItemClick(Post post);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public static class PostViewHolder extends RecyclerView.ViewHolder {
        TextView userNameTextView;
        TextView tag1TextView;
        TextView tag2TextView;

        public PostViewHolder(View itemView, final OnItemClickListener listener, final List<Post> postList) {
            super(itemView);
            userNameTextView = itemView.findViewById(R.id.userNameTextView);
            tag1TextView = itemView.findViewById(R.id.tag1);
            tag2TextView = itemView.findViewById(R.id.tag2);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(postList.get(position));
                }
            });
        }
    }

    public PostAdapter(List<Post> postList) {
        this.postList = postList;
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_post, parent, false);
        return new PostViewHolder(v, listener, postList);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        Post post = postList.get(position);
        holder.userNameTextView.setText(post.getUserName());

        List<String> tags = post.getTags();
        if (tags.size() > 0) holder.tag1TextView.setText(tags.get(0));
        if (tags.size() > 1) holder.tag2TextView.setText(tags.get(1));
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }
}

