package com.example.project;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Calendar_ReminderUtils {

    public static final String NONE = "None";

    /**
     * ✅ Overload to schedule reminder from Calendar_Event
     */
    public static void scheduleReminder(Context context, Calendar_Event event) {
        if (event == null) return;

        try {
            Calendar cal = Calendar.getInstance();
            String dateTime = event.getDate() + " " + event.getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            cal.setTime(sdf.parse(dateTime));

            scheduleReminder(context, event.getId(), event.getTitle(), event.getDate(),
                    cal, event.getReminder());
        } catch (ParseException e) {
            Log.e("Calendar_ReminderUtils", "Failed to parse date/time for reminder", e);
        }
    }

    /**
     * ✅ Expanded reminder scheduling
     */
    public static void scheduleReminder(Context context, String eventId, String title, String date,
                                        Calendar cal, String reminder) {
        if (reminder == null || reminder.equals(NONE)) return;

        long triggerAt = cal.getTimeInMillis();

        switch (reminder) {
            case "1 hour before":
                triggerAt -= 60 * 60 * 1000;
                break;
            case "45 min before":
                triggerAt -= 45 * 60 * 1000;
                break;
            case "30 min before":
                triggerAt -= 30 * 60 * 1000;
                break;
            case "15 min before":
                triggerAt -= 15 * 60 * 1000;
                break;
        }

        if (triggerAt < System.currentTimeMillis()) {
            Log.d("Calendar_ReminderUtils", "⏰ Skipping past reminder for " + title);
            return;
        }

        Intent intent = new Intent(context, Calendar_ReminderBroadcastReceiver.class);

// Pass event details so the BroadcastReceiver can show time/date
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
        String timeStr = timeFormat.format(cal.getTime());

        intent.putExtra("eventId", eventId);
        intent.putExtra("title", title);
        intent.putExtra("time", timeStr);   // ✅ added
        intent.putExtra("date", date);      // ✅ added

        Log.d("Calendar_ReminderUtils", "➡ Scheduling reminder extras: time=" + timeStr + " date=" + date + " id=" + eventId);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                eventId.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );


        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
            Log.d("Calendar_ReminderUtils", "⏰ Reminder set for " + title + " at " + triggerAt);
        }
    }

    /**
     * ✅ Overload to cancel reminder from Calendar_Event
     */
    public static void cancelReminder(Context context, Calendar_Event event) {
        if (event != null) {
            cancelReminder(context, event.getId());
        }
    }

    /**
     * ✅ Expanded cancel reminder
     */
    public static void cancelReminder(Context context, String eventId) {
        Intent intent = new Intent(context, Calendar_ReminderBroadcastReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                eventId.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
            Log.d("Calendar_ReminderUtils", "❌ Reminder cancelled for event " + eventId);
        }
    }
}
