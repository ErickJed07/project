package com.example.project;

public class Closet_CategoryFirebase {
    public String id;
    public String name;

    public Closet_CategoryFirebase() {
        // Needed for Firebase
    }

    public Closet_CategoryFirebase(String id, String name) {
        this.id = id;
        this.name = name;
    }
}

