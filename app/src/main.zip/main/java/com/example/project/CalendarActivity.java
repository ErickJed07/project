package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class CalendarActivity extends AppCompatActivity {

    private GridLayout calendarGrid;
    private TextView monthLabel;
    private Calendar calendar;
    private TextView selectedDayView = null;

    private RecyclerView eventRecyclerView;
    private Calendar_EventAdapter calendarEventAdapter;
    private List<Calendar_Event> calendarEventList = new ArrayList<>();

    private Map<String, List<Calendar_Event>> eventMap = new HashMap<>();
    private String selectedDateString = "";

    private DatabaseReference eventsRef;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar);

        // ✅ Firebase setup
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        eventsRef = FirebaseDatabase.getInstance()
                .getReference("CalendarEvents")
                .child(userId);

        // ✅ Step 1: Request notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        calendarGrid = findViewById(R.id.calendar_grid);
        monthLabel = findViewById(R.id.month_label);
        ImageButton prevMonth = findViewById(R.id.prev_month);
        ImageButton nextMonth = findViewById(R.id.next_month);

        eventRecyclerView = findViewById(R.id.eventRecyclerView);
        eventRecyclerView.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        // ✅ Event adapter with delete support using eventId
        calendarEventAdapter = new Calendar_EventAdapter(calendarEventList, (event, position) -> {
            if (selectedDateString != null && !selectedDateString.isEmpty() && event.getId() != null) {
                // Cancel scheduled reminder (if any)
                Calendar_ReminderUtils.cancelReminder(CalendarActivity.this, event);

                // Remove from Firebase under date node
                eventsRef.child(selectedDateString).child(event.getId()).removeValue();
            }
        });

        eventRecyclerView.setAdapter(calendarEventAdapter);

        calendar = Calendar.getInstance();
        updateCalendar();

        prevMonth.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, -1);
            updateCalendar();
        });

        nextMonth.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, 1);
            updateCalendar();
        });

        // ✅ Default selected date = today
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        selectedDateString = df.format(calendar.getTime());

        // ✅ Load events in real-time from Firebase
        loadEventsFromFirebase();
    }

    private void updateCalendar() {
        calendarGrid.removeAllViews();

        // Show month/year label
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy", Locale.getDefault());
        monthLabel.setText(sdf.format(calendar.getTime()));

        Calendar todayCalendar = Calendar.getInstance();
        int today = todayCalendar.get(Calendar.DAY_OF_MONTH);
        boolean isCurrentMonth = todayCalendar.get(Calendar.MONTH) == calendar.get(Calendar.MONTH) &&
                todayCalendar.get(Calendar.YEAR) == calendar.get(Calendar.YEAR);

        Calendar tempCalendar = (Calendar) calendar.clone();
        tempCalendar.set(Calendar.DAY_OF_MONTH, 1);
        int firstDayOfWeek = tempCalendar.get(Calendar.DAY_OF_WEEK) - 1;
        int daysInMonth = tempCalendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        int totalCells = 42;

        for (int i = 0; i < totalCells; i++) {
            TextView dayView = createDayView();

            if (i >= firstDayOfWeek && i < firstDayOfWeek + daysInMonth) {
                int day = i - firstDayOfWeek + 1;
                dayView.setText(String.valueOf(day));
                dayView.setTag(day);

                dayView.setOnClickListener(v -> {
                    // Reset old selection
                    if (selectedDayView != null && selectedDayView != dayView) {
                        int previousDay = (int) selectedDayView.getTag();
                        selectedDayView.setText(String.valueOf(previousDay));
                        selectedDayView.setBackgroundColor(
                                getResources().getColor(R.color.calendar_day_bg));
                        selectedDayView.setTextColor(getResources().getColor(R.color.black));
                    }

                    // Highlight new selection
                    dayView.setBackgroundColor(
                            getResources().getColor(R.color.calendar_day_selected));
                    dayView.setTextColor(getResources().getColor(R.color.white));
                    selectedDayView = dayView;

                    int clickedDay = (int) dayView.getTag();
                    Calendar clickedDate = (Calendar) calendar.clone();
                    clickedDate.set(Calendar.DAY_OF_MONTH, clickedDay);
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    selectedDateString = df.format(clickedDate.getTime());

                    // ✅ Refresh events for selected date
                    loadEventsForSelectedDate();
                });

                // Auto select today
                if (isCurrentMonth && day == today) {
                    selectedDayView = dayView;
                    dayView.setBackgroundColor(
                            getResources().getColor(R.color.calendar_day_selected));
                    dayView.setTextColor(getResources().getColor(R.color.white));
                }

            } else {
                dayView.setText(getAdjacentDay(i, firstDayOfWeek, daysInMonth));
                dayView.setTextColor(getResources().getColor(R.color.gray));
            }

            calendarGrid.addView(dayView);
        }
    }

    private TextView createDayView() {
        TextView dayView = new TextView(this);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(4, 4, 4, 4);

        dayView.setLayoutParams(params);
        dayView.setGravity(Gravity.CENTER);
        dayView.setPadding(30, 40, 30, 40);
        dayView.setTextSize(18);
        dayView.setBackgroundColor(getResources().getColor(R.color.calendar_day_bg));
        dayView.setTextColor(getResources().getColor(R.color.black));
        return dayView;
    }

    private void loadEventsFromFirebase() {
        eventsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                eventMap.clear();

                // 🔥 Loop directly over events (flat structure)
                for (DataSnapshot eventSnapshot : snapshot.getChildren()) {
                    Calendar_Event event = eventSnapshot.getValue(Calendar_Event.class);
                    if (event != null) {
                        event.setId(eventSnapshot.getKey());

                        // Group events by their date
                        String date = event.getDate();
                        if (date != null && !date.isEmpty()) {
                            if (!eventMap.containsKey(date)) {
                                eventMap.put(date, new ArrayList<>());
                            }
                            eventMap.get(date).add(event);
                        }

                        // Schedule reminder if needed
                        Calendar_ReminderUtils.scheduleReminder(CalendarActivity.this, event);
                    }
                }

                // Refresh events for the currently selected date
                loadEventsForSelectedDate();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // TODO: Add proper logging/Toast later
            }
        });
    }

    private void loadEventsForSelectedDate() {
        List<Calendar_Event> selectedCalendarEvents =
                eventMap.getOrDefault(selectedDateString, new ArrayList<>());
        calendarEventList.clear();
        calendarEventList.addAll(selectedCalendarEvents);
        calendarEventAdapter.notifyDataSetChanged();
    }

    public void onButtonClicked(View view) {
        Intent intent = null;
        int viewId = view.getId();

        if (viewId == R.id.home_menu) {
            intent = new Intent(this, FeedActivity.class);
        } else if (viewId == R.id.calendar_menu) {
            return;
        } else if (viewId == R.id.camera_menu) {
            intent = new Intent(this, CameraActivity.class);
        } else if (viewId == R.id.closet_menu) {
            intent = new Intent(this, ClosetActivity.class);
        } else if (viewId == R.id.profile_menu) {
            intent = new Intent(this, ProfileActivity.class);
        }

        if (intent != null) {
            startActivity(intent);
            finish();
        }
    }

    private String getAdjacentDay(int cellIndex, int firstDayOfWeek, int daysInMonth) {
        Calendar temp = (Calendar) calendar.clone();

        if (cellIndex < firstDayOfWeek) {
            temp.add(Calendar.MONTH, -1);
            int prevMonthDays = temp.getActualMaximum(Calendar.DAY_OF_MONTH);
            int day = prevMonthDays - (firstDayOfWeek - cellIndex) + 1;
            return String.valueOf(day);
        } else {
            int day = (cellIndex - firstDayOfWeek - daysInMonth) + 1;
            return String.valueOf(day);
        }
    }
}
