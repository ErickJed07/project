// FeedActivity.java
package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Arrays;
import java.util.List;

public class FeedActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private PostAdapter adapter;
    private List<Post> postList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feed);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample data
        postList = Arrays.asList(
                new Post("Alice", Arrays.asList("Casual", "Summer")),
                new Post("Bob", Arrays.asList("Formal", "Work")),
                new Post("Charlie", Arrays.asList("Streetwear", "Winter")),
                new Post("Alice", Arrays.asList("Casual", "Summer")),
                new Post("Bob", Arrays.asList("Formal", "Work")),
                new Post("Charlie", Arrays.asList("Streetwear", "Winter"))
        );

        adapter = new PostAdapter(postList);
        recyclerView.setAdapter(adapter);
    }


public void onButtonClicked(View view) {
        Intent intent = null;
        int viewId = view.getId();

        if (viewId == R.id.home_menu) {
            return;
        } else if (viewId == R.id.calendar_menu) {
            intent = new Intent(this, CalendarActivity.class);
        } else if (viewId == R.id.camera_menu) {
            intent = new Intent(this, CameraActivity.class);
        } else if (viewId == R.id.closet_menu) {
            intent = new Intent(this, ClosetActivity.class);
        } else if (viewId == R.id.profile_menu) {
            intent = new Intent(this, ProfileActivity.class);
        }

        if (intent != null) {
            startActivity(intent);
            finish();
        }
    }
}
