package com.example.project;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private TextView emailLabel, passwordLabel;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login); // your XML layout file name

        // Firebase init
        mAuth = FirebaseAuth.getInstance();

        // Inputs
        emailInput = findViewById(R.id.email_info);
        passwordInput = findViewById(R.id.pass_info);

        // Labels
        emailLabel = findViewById(R.id.email);
        passwordLabel = findViewById(R.id.pass);

        Button loginButton = findViewById(R.id.loginbutton);

        loginButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Reset label colors
            resetColors();

            if (email.isEmpty()) {
                emailLabel.setTextColor(Color.RED);
                Toast.makeText(this, "Enter your Email", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                passwordLabel.setTextColor(Color.RED);
                Toast.makeText(this, "Enter your Password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Perform Firebase Authentication
            mAuth.signInWithEmailAndPassword(email, password) // Correctly use the email as is
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            // Check if the user is logged in
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                // Redirect to FeedActivity after successful login
                                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(LoginActivity.this, FeedActivity.class)); // Navigate to FeedActivity
                                finish();
                            }
                        } else {
                            Toast.makeText(this, "Login failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        });
    }

    // Reset label colors to black
    private void resetColors() {
        emailLabel.setTextColor(Color.BLACK);
        passwordLabel.setTextColor(Color.BLACK);
    }
}
