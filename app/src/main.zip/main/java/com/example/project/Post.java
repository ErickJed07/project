package com.example.project;

import java.util.List;

public class Post {
    private String userName;
    private List<String> tags;

    public Post(String userName, List<String> tags) {
        this.userName = userName;
        this.tags = tags;
    }

    public String getUserName() {
        return userName;
    }

    public List<String> getTags() {
        return tags;
    }
}
