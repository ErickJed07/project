package com.example.project;

import android.graphics.Bitmap;

public class Camera_ImageHolder {
    public static Bitmap bitmap = null;
}
