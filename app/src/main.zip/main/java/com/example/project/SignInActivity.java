package com.example.project;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class SignInActivity extends AppCompatActivity {

    private EditText emailInput, usernameInput, passwordInput, confirmPasswordInput;
    private TextView emailLabel, usernameLabel, passwordLabel, confirmPasswordLabel;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin); // your XML file name

        // Firebase init
        mAuth = FirebaseAuth.getInstance();

        // Inputs
        emailInput = findViewById(R.id.email_info);
        usernameInput = findViewById(R.id.create_user_info);
        passwordInput = findViewById(R.id.create_pass_info);
        confirmPasswordInput = findViewById(R.id.confirm_pass_info);

        // Labels
        emailLabel = findViewById(R.id.email);
        usernameLabel = findViewById(R.id.create_user);
        passwordLabel = findViewById(R.id.create_pass);
        confirmPasswordLabel = findViewById(R.id.confirm_pass);

        Button signinButton = findViewById(R.id.signinbutton);

        signinButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();

            // Reset label colors
            resetColors();

            if (email.isEmpty()) {
                emailLabel.setTextColor(Color.RED);
                Toast.makeText(this, "Enter Your Email", Toast.LENGTH_SHORT).show();
                return;
            }
            if (username.isEmpty()) {
                usernameLabel.setTextColor(Color.RED);
                Toast.makeText(this, "Enter Your Username", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                passwordLabel.setTextColor(Color.RED);
                Toast.makeText(this, "Enter Your Password", Toast.LENGTH_SHORT).show();
                return;
            }
            if (confirmPassword.isEmpty()) {
                confirmPasswordLabel.setTextColor(Color.RED);
                Toast.makeText(this, "Enter Confirm Password", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.equals(confirmPassword)) {
                confirmPasswordLabel.setTextColor(Color.RED);
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // Register with Firebase
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            // Get user ID after registration
                            String uid = mAuth.getCurrentUser().getUid();

                            // Get Firebase Realtime Database reference
                            DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Users");

                            // Create a map to store the user's data (email and username)
                            Map<String, Object> userMap = new HashMap<>();
                            userMap.put("email", email);
                            userMap.put("username", username);

                            // Save user data to the Realtime Database under the unique user ID
                            databaseRef.child(uid).setValue(userMap)
                                    .addOnCompleteListener(dbTask -> {
                                        if (dbTask.isSuccessful()) {
                                            Toast.makeText(this, "Account created and saved", Toast.LENGTH_SHORT).show();
                                            // Redirect to login activity after successful registration
                                            startActivity(new Intent(SignInActivity.this, LoginActivity.class));
                                            finish();
                                        } else {
                                            Toast.makeText(this, "Failed to save user: " + dbTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    });
                        } else {
                            Toast.makeText(this, "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        });
    }

    // Reset label colors
    private void resetColors() {
        emailLabel.setTextColor(Color.BLACK);
        usernameLabel.setTextColor(Color.BLACK);
        passwordLabel.setTextColor(Color.BLACK);
        confirmPasswordLabel.setTextColor(Color.BLACK);
    }
}
