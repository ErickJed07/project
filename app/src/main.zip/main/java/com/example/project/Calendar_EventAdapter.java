package com.example.project;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;
import java.util.List;

public class Calendar_EventAdapter extends RecyclerView.Adapter<Calendar_EventAdapter.EventViewHolder> {

    private final List<Calendar_Event> calendarEventList;

    public interface OnEventDeleteListener {
        void onEventDeleted(Calendar_Event event, int position);
    }

    private final OnEventDeleteListener deleteListener;

    public Calendar_EventAdapter(List<Calendar_Event> calendarEventList, OnEventDeleteListener deleteListener) {
        this.calendarEventList = calendarEventList;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.calendar_item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Calendar_Event calendarEvent = calendarEventList.get(position);
        holder.eventTitle.setText(calendarEvent.getTitle());

        String imagePath = calendarEvent.getImagePath();
        if (imagePath != null && !imagePath.isEmpty()) {
            if (imagePath.startsWith("android.resource://")) {
                holder.eventImage.setImageURI(Uri.parse(imagePath));
            } else {
                File imgFile = new File(imagePath);
                if (imgFile.exists()) {
                    Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                    holder.eventImage.setImageBitmap(bitmap);
                } else {
                    holder.eventImage.setImageResource(R.drawable.image1);
                }
            }
        } else {
            holder.eventImage.setImageResource(R.drawable.image1);
        }

        View.OnClickListener showDialogListener = v -> {
            Context context = v.getContext();
            View dialogView = LayoutInflater.from(context).inflate(R.layout.calendar_popup_event_info, null);

            // Match views from popup layout
            TextView popupTitle = dialogView.findViewById(R.id.popupTitle);
            ImageView popupImage = dialogView.findViewById(R.id.popupImage);
            TextView popupTime = dialogView.findViewById(R.id.popupTime);
            TextView popupReminder = dialogView.findViewById(R.id.popupReminder);

            Button closeButton = dialogView.findViewById(R.id.closeButton);
            Button deleteButton = dialogView.findViewById(R.id.deleteButton);

            // Set popup data
            popupTitle.setText(calendarEvent.getTitle());
            popupTime.setText("Time: " + calendarEvent.getTime());

            if (calendarEvent.getReminder() == null || calendarEvent.getReminder().equals("None")) {
                popupReminder.setVisibility(View.GONE);
            } else {
                popupReminder.setVisibility(View.VISIBLE);
                popupReminder.setText("Reminder: " + calendarEvent.getReminder());
            }

            if (imagePath != null && !imagePath.isEmpty()) {
                if (imagePath.startsWith("android.resource://")) {
                    popupImage.setImageURI(Uri.parse(imagePath));
                } else {
                    File imgFile = new File(imagePath);
                    if (imgFile.exists()) {
                        Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                        popupImage.setImageBitmap(bitmap);
                    } else {
                        popupImage.setImageResource(R.drawable.image3);
                    }
                }
            } else {
                popupImage.setImageResource(R.drawable.image3);
            }

            // Build dialog
            final androidx.appcompat.app.AlertDialog dialog = new MaterialAlertDialogBuilder(context)
                    .setView(dialogView)
                    .setCancelable(true)
                    .create();

            // Close
            closeButton.setOnClickListener(x -> dialog.dismiss());


            // Delete
            deleteButton.setOnClickListener(x -> {
                int pos = holder.getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) {
                    Calendar_Event eventToDelete = calendarEventList.get(pos);

                    // Remove from adapter list
                    calendarEventList.remove(pos);
                    notifyItemRemoved(pos);

                    // Notify parent (CalendarActivity) to remove from Firebase
                    if (deleteListener != null) {
                        deleteListener.onEventDeleted(eventToDelete, pos);
                    }

                    dialog.dismiss();
                    Toast.makeText(context,
                            "Deleted: " + eventToDelete.getTitle(),
                            Toast.LENGTH_SHORT).show();
                }
            });

            dialog.show();
        };

        holder.eventMore.setOnClickListener(showDialogListener);
        holder.itemView.setOnClickListener(showDialogListener);
    }

    @Override
    public int getItemCount() {
        return calendarEventList.size();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventTitle, eventMore;
        ImageView eventImage;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.eventTitle);
            eventMore = itemView.findViewById(R.id.eventMore);
            eventImage = itemView.findViewById(R.id.eventImage);
        }
    }
}